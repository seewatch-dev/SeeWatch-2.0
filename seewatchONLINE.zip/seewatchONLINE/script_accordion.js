// Accordion 
function myAccFuncCountry() {
  var x = document.getElementById("demoAcc1");
  if (x.className.indexOf(" show") == -1) {
    x.className += " show";
  } else {
    x.className = x.className.replace(" show", "");
  }
}

// Accordion 
function myAccFuncPlus() {
  var x = document.getElementById("demoAcc2");
  if (x.className.indexOf(" show") == -1) {
    x.className += " show";
  } else {
    x.className = x.className.replace(" show", "");
  }
}

// Accordion 
function myAccFuncMarques() {
  var x = document.getElementById("demoAccMarques");
  if (x.className.indexOf(" show") == -1) {
    x.className += " show";
  } else {
    x.className = x.className.replace(" show", "");
  }
}